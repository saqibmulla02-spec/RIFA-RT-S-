# RIFA ART'S (رفعہ آرٹس) — Android folder (cyan UI, v6)

- `www/index.html` — the whole app (open in Chrome to test).
- `www/fonts/` — 92 Urdu fonts (converted to .woff, about 22 MB) + `fonts.js` (the list).
- `capacitor.config.json`, `package.json` — wrap as an Android APK.

## Build the APK (on your PC)
1. `npm install`  2. `npx cap add android` (first time)  3. `npx cap sync android`  4. `npx cap open android` → Build APK
The fonts make the APK large (about 25 MB). If that is too big, delete fonts you don't use from `www/fonts/` and from `fonts.js`.

## New in v3
- Fonts window: search box, every font listed with an Urdu sample drawn in that font, selected font highlighted, "Import font file (Custom)" at the end.
- Master Page (Pages panel > Edit Master Page): anything placed there repeats on every page. Add > Page Number inserts {page}, which becomes the real number on each page.
- Table (Add > Table): rows/columns, tap a cell to edit its text and fill, add/remove rows and columns, header row, grid width/colour, font, custom size.
- Photo: Remove BG (plain backgrounds), Remove Color (pick a colour from the photo + tolerance, Restore), Trace (black & white to vector).
- Save: JPG, PNG, Transparent PNG, or PDF of all pages (pages are images inside the PDF, not vector).

## Not done yet
Feather, Perspective, Blend Color, Crop, Draw, Pen Tool, Stock Images, Stickers, Logos, Translation, AI Write, Animate, merge cells in tables, colour trace, true vector PDF.
Custom fonts you import last only for the current session. Not tested on a real device. In the APK, saving files needs Capacitor Filesystem/Share.

## New in v4
- Home screen like the mockup: logo, اردو / English switch, hero banner, New Document, Open Project, Fonts, Quick Sizes (A4, A3, A5, Poster 12x18, Social, Story, Custom Size), Recent Projects with thumbnails (rename / delete with the ⋮ button).
- Whole app interface in Urdu or English (button on the home screen or in Settings). Urdu mode shows right-to-left panels. A few rare messages are still English.
- Quick sizes store real DPI: Save opens with the print width (A4 at 300 DPI = 2480 px).
- Projects autosave inside the app (IndexedDB). Save > Project File (.saqib) makes a file you can open again with Open Project.
- Tapping Fonts on the home screen sets the default font for new text.

## New in v5
- Renamed to RIFA ART'S / رفعہ آرٹس (title, home, logo, Urdu mode). The Android package id (`com.saqibarts.studio`) and saved data keys are unchanged, so existing projects and updates keep working.
- Transform panel (tool "Transform" on any selected object): X, Y, W, H, Rotation, units px / mm / cm / in / ft, Lock Ratio, Apply / Done, error messages for empty, zero, tiny or huge sizes. 1 inch = 72 internal units; px uses the document DPI (A4 at 300 DPI: 2479 px wide). Dragging handles on the canvas still works with it.
- New shapes: Star and Polygon (editable vector shapes).
- New light Layers panel: thumbnails/icons, rename, duplicate, delete, show/hide, lock, drag the grip to reorder, groups that expand/collapse (with group hide/lock), tick boxes + Group / Ungroup. Phone: drawer at the top, the canvas view moves below it. Desktop (wide screen): side panel on the right with a draggable edge. Design data is never changed by opening or closing it.
- Urdu text: each line gets its own direction (Urdu, English and numbers can be mixed), letter spacing is turned off for Urdu so letters stay joined, exports follow the same rules.
- Imported fonts (TTF/OTF/WOFF) are now saved in the app and embedded in Project File (.saqib). If a project uses a font that is not available, the text gets a red dotted outline and a warning appears; the font is never swapped silently.

## Limits
Urdu typing happens in the text box in the tool strip (not directly on the canvas). Nastaleeq quality depends on the browser/WebView text engine and the font file; not verified on a real phone. Not tested: layers panel on a physical device, PDF/PNG visual check of Urdu output.

## New in v6
- Letter Spacing fixed (it was switched off for Urdu/Arabic). Script-aware, per line: English, Hindi, Kannada lines get real letter spacing; lines that contain Urdu/Arabic keep every letter joined and the spacing is applied between words instead. Range -10 to 40, number box + slider, live, saved in the project, same result in PNG/JPG/PDF export. Limit: inside an Urdu word letters are never pulled apart, and in a mixed Urdu+English line the English letters are not spaced.
- Properties bar above the canvas (always reserved, so the page never jumps when you select something): X, Y, W, H, unit (px/mm/cm/in/ft), lock ratio, rotation. Text adds font, size, letter spacing, line spacing, align, direction (auto/RTL/LTR), colour. Shapes add fill, outline colour, line width. Photos show their aspect ratio. Values apply on Enter or when you leave the field.
- Selection box with 8 resize handles and a rotation handle (cursors follow the rotation, handle size does not change with zoom). The selection drawing is a separate overlay, so it is never part of exported files.
- Floating toolbar with exactly 4 buttons: Move, Duplicate, Delete (red), More Options. It sits below the object, or above/inside the workspace when there is no room. More Options: edit text, arrange (forward/backward/front/back), align to page, group/ungroup, lock, rotate 90, flip, custom size, opacity, fill, outline, properties.
- Drawing: choose Rectangle, Square, Ellipse, Rounded, Line, Star or Polygon in Add New, then drag on the page. The new object is selected with handles, toolbar and its size in the properties bar.

## Tested here / not tested
Tested with scripts: JavaScript syntax; the resize maths (opposite edge stays fixed for all 8 handles at 0, 30, 90, -45 degrees); unit conversion; which lines get which spacing rule.
Not tested (no phone/browser available here): touch dragging, cursor shapes, toolbar placement at screen edges, Urdu spacing look, PNG/PDF output, save-and-reopen. Please try them on your phone.

## Build the APK on GitHub (no Android Studio)
1. Create a new repository on github.com (private is fine).
2. Upload the CONTENTS of this Android folder (www, .github, package.json, capacitor.config.json, .gitignore) to the repository root. The web uploader accepts 100 files at a time, so upload `www/fonts` in a second batch, or use GitHub Desktop / git.
3. Open the Actions tab > "Build APK" > Run workflow (it also runs on every push).
4. After about 5-10 minutes open the finished run and download "RIFA-ARTS-debug-apk" from Artifacts. Unzip it to get app-debug.apk.
The phone label is "RIFA ARTS" (an apostrophe in the label can break the Android build). Not run here; the first run may need small fixes.
